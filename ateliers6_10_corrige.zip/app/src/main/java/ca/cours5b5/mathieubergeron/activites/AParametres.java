package ca.cours5b5.mathieubergeron.activites;

import android.os.Bundle;

import ca.cours5b5.mathieubergeron.R;
import ca.cours5b5.mathieubergeron.controleurs.ControleurModeles;
import ca.cours5b5.mathieubergeron.controleurs.interfaces.Fournisseur;
import ca.cours5b5.mathieubergeron.modeles.MParametres;

public class AParametres extends Activite implements Fournisseur{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parametres);

    }

    @Override
    protected void onPause() {
        super.onPause();

        ControleurModeles.sauvegarderModele(MParametres.class.getSimpleName());

    }

}
