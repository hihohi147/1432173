package ca.cours5b5.mathieubergeron.global;



public enum GCommande {

    CHOISIR_HAUTEUR,
    CHOISIR_LARGEUR,
    CHOISIR_POUR_GAGNER,

    OUVRIR_MENU_PARAMETRES,
    DEMARRER_PARTIE,

    JOUER_COUP_ICI,

}
