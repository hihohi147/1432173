package ca.cours5b5.mathieubergeron.controleurs.interfaces;


public abstract class ListenerFournisseur {

    public abstract void executer(Object... args);

}
