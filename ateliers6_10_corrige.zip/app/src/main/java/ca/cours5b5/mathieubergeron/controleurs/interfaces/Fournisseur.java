package ca.cours5b5.mathieubergeron.controleurs.interfaces;

public interface Fournisseur {}
